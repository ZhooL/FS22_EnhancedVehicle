--
-- Mod: FS22_EnhancedVehicle_UI
--
-- Author: Majo76
-- email: ls22@dark-world.de
-- @Date: 01.12.2021
-- @Version: 1.0.0.0

local myName = "FS22_EnhancedVehicle_UI"

FS22_EnhancedVehicle_UI = {}

local FS22_EnhancedVehicle_UI_mt = Class(FS22_EnhancedVehicle_UI)

-- #############################################################################

function FS22_EnhancedVehicle_UI:new(mission, i18n, modDirectory, gui, inputManager, messageCenter)
  if debug > 1 then print("-> " .. myName .. ": new ") end

  local self = setmetatable({}, FS22_EnhancedVehicle_UI_mt)

  self.mission       = mission
  self.i18n          = i18n
  self.modDirectory  = modDirectory
  self.gui           = gui
  self.inputManager  = inputManager
  self.messageCenter = messageCenter
  self.isClient      = mission:getIsClient()

--  self.uiFilename    = Utils.getFilename("resources/guidanceSteering_1080p.png", modDirectory)

  self.vehicle = nil

  return self
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:delete()
  if debug > 1 then print("-> " .. myName .. ": delete ") end

  if self.isClient then
    self:unloadMenu()
  end
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:load()
  if debug > 1 then print("-> " .. myName .. ": load ") end

  if self.isClient then
    self.gui:loadProfiles(Utils.getFilename("resources/guiProfiles.xml", self.modDirectory))

    self:loadMenu()
  end
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:loadMenu()
  if debug > 1 then print("-> " .. myName .. ": loadMenu ") end

  local globalSettingsFrame = FS22_EnhancedVehicle_Frame_GlobalSettings:new(self, self.i18n)
  local snapSettingsFrame   = FS22_EnhancedVehicle_Frame_SnapSettings:new(self, self.i18n)

  self.menu = FS22_EnhancedVehicle_Menu:new(self.messageCenter, self.i18n, self.inputManager)

  local root = Utils.getFilename("resources/", self.modDirectory)
  self.gui:loadGui(root .. "FS22_EnhancedVehicle_Frame_GlobalSettings.xml", "FS22_EnhancedVehicle_Frame_GlobalSettings", globalSettingsFrame, true)
  self.gui:loadGui(root .. "FS22_EnhancedVehicle_Frame_SnapSettings.xml",   "FS22_EnhancedVehicle_Frame_SnapSettings",   snapSettingsFrame,   true)
  self.gui:loadGui(root .. "FS22_EnhancedVehicle_Menu.xml",                 "FS22_EnhancedVehicle_Menu",                 self.menu)
  print("ende auch")

end

-- #############################################################################

function FS22_EnhancedVehicle_UI:unloadMenu()
  if debug > 1 then print("-> " .. myName .. ": unloadMenu ") end

  self.menu:delete()
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:onToggleUI()
  if debug > 1 then print("-> " .. myName .. ": onToggleUI ") end

  if not self.mission.isSynchronizingWithPlayers then
    self.gui:showGui("FS22_EnhancedVehicle_Menu")
  end
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:setVehicle(vehicle)
  if debug > 1 then print("-> " .. myName .. ": setVehicle ") end

  self.vehicle = vehicle
--  self.hud:setVehicle(vehicle)
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:getVehicle()
  if debug > 1 then print("-> " .. myName .. ": getVehicle ") end

  return self.vehicle
end

-- #############################################################################

function FS22_EnhancedVehicle_UI:draw()
  if debug > 1 then print("-> " .. myName .. ": draw ") end
end
