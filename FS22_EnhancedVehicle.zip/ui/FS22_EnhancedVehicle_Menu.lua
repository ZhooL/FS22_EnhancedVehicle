--
-- Mod: FS22_EnhancedVehicle_Menu
--
-- Author: Majo76
-- email: ls22@dark-world.de
-- @Date: 01.12.2021
-- @Version: 1.0.0.0

local myName = "FS22_EnhancedVehicle_Menu"

FS22_EnhancedVehicle_Menu = {}
local FS22_EnhancedVehicle_Menu_mt = Class(FS22_EnhancedVehicle_Menu, TabbedMenu)

FS22_EnhancedVehicle_Menu.CONTROLS = {
    PAGE_GLOBALSETTINGS = "pageGlobalSettings",
    PAGE_SNAPSETTINGS   = "pageSnapSettings",
    DIALOG_BACKGROUND   = "dialogBackground",
}

-- #############################################################################

function FS22_EnhancedVehicle_Menu:new(messageCenter, i18n, inputManager)
  if debug > 1 then print("-> " .. myName .. ": new ") end

  local self = TabbedMenu:new(nil, FS22_EnhancedVehicle_Menu_mt, messageCenter, i18n, inputManager)

  self.i18n = i18n
  self:registerControls(FS22_EnhancedVehicle_Menu.CONTROLS)

print("ende")
  return self
end

-- #############################################################################

function FS22_EnhancedVehicle_Menu:onGuiSetupFinished()
print("warum")
  if debug > 1 then print("-> " .. myName .. ": onGuiSetupFinished ") end

  FS22_EnhancedVehicle_Menu:superClass().onGuiSetupFinished(self)

  self.clickBackCallback = self:makeSelfCallback(self.onButtonBack)

--    if g_screenWidth >= 2560 and g_screenHeight >= 1080 then
--        self.dialogBackground:applyProfile("guidanceSteeringDialogBgWide")
--        self.header:applyProfile("guidanceSteeringMenuHeaderWide")
--        self.pageSelector:applyProfile("guidanceSteeringHeaderSelectorWide")
--        self.pagingTabList:applyProfile("guidanceSteeringPagingTabListWide")
--    end

  self.pageGlobalSettings:initialize()
  self.pageSnapSettings:initialize()
  self:setupPages()
end

-- #############################################################################

function FS22_EnhancedVehicle_Menu:setupPages()
  if debug > 1 then print("-> " .. myName .. ": setupPages ") end

  local alwaysVisiblePredicate = self:makeIsAlwaysVisiblePredicate()

  local orderedPages = {
    { self.pageGlobalSettings, alwaysVisiblePredicate, g_baseUIFilename, FS22_EnhancedVehicle_Menu.TAB_UV.EV_GLOBALSETTINGS, "EV_GlobalSettings" },
    { self.pageSnapSettings,   alwaysVisiblePredicate, g_baseUIFilename, FS22_EnhancedVehicle_Menu.TAB_UV.EV_SNAPSETTINGS,   "EV_SnapSettings" },
  }

  for i, pageDef in ipairs(orderedPages) do
    local page, predicate, uiFilename, iconUVs = unpack(pageDef)
    self:registerPage(page, i, predicate)

--    page.callBackParent = self;
--    page.callBackParentWithID = i;

    local normalizedUVs = getNormalizedUVs(iconUVs)
    self:addPageTab(page, uiFilename, normalizedUVs)
  end
end

-- #############################################################################

function FS22_EnhancedVehicle_Menu:onOpen()
  if debug > 1 then print("-> " .. myName .. ": onOpen ") end

  FS22_EnhancedVehicle_Menu:superClass().onOpen(self)

  self.inputDisableTime = 200
end

-- #############################################################################

function FS22_EnhancedVehicle_Menu:setupMenuButtonInfo()
  if debug > 1 then print("-> " .. myName .. ": setupMenuButtonInfo ") end

  local onButtonBackFunction = self.clickBackCallback

  self.defaultMenuButtonInfo = {
--    { inputAction = InputAction.MENU_BACK, text = self.l10n:getText(FS22_EnhancedVehicle_Menu.L10N_SYMBOL.BUTTON_BACK), callback = onButtonBackFunction },
    { inputAction = InputAction.MENU_BACK, text = "lala", callback = onButtonBackFunction },
  }

  self.defaultMenuButtonInfoByActions[InputAction.MENU_BACK] = self.defaultMenuButtonInfo[1]

  self.defaultButtonActionCallbacks = {
      [InputAction.MENU_BACK] = onButtonBackFunction,
  }
end

-- #############################################################################

function FS22_EnhancedVehicle_Menu:makeIsAlwaysVisiblePredicate()
  if debug > 1 then print("-> " .. myName .. ": makeIsAlwaysVisiblePredicate ") end

  return function()
    return true
  end
end

-- #############################################################################
FS22_EnhancedVehicle_Menu.TAB_UV = {
  EV_GLOBALSETTINGS = { 0, 209, 65, 65 },
  EV_SNAPSETTINGS = { 845, 0, 65, 65 },
}

FS22_EnhancedVehicle_Menu.L10N_SYMBOL = {
  BUTTON_BACK = "button_back",
}
